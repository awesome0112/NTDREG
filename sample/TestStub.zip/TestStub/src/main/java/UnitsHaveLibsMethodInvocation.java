public class UnitsHaveLibsMethodInvocation {
    public static boolean isPrime(int x) {
        if (x <= 1) return false;
        double d = x;
        for (int i = 2; i <= Math.sqrt(d); i++) {
            if (d % i == 0) return false;
        }
        return true;
    }

    public static int checkTriangleType(double a, double b, double c) {
        if (a + b <= c || a + c <= b || b + c <= a) {
            return -1;
        }

        if (a == b && b == c) {
            return 3;
        } else if (a == b || b == c || a == c) {
            return 2;
        } else {
            double maxBC = Math.max(b, c);
            double hypotenuse = Math.max(a, maxBC);
            double minAB = Math.min(a, b);
            double side1 = Math.min(minAB, c);
            double side2 = a + b + c - hypotenuse - side1;

            double hypotenuseSquared = Math.pow(hypotenuse, 2.0);
            double side1Squared = Math.pow(side1, 2.0);
            double side2Squared = Math.pow(side2, 2.0);

            if (hypotenuseSquared - (side1Squared + side2Squared) < 0.0001) {
                return 1;
            }
        }

        return 0;
    }

    public static long sumOfPrimesBelow(int n) {
        long sum = 0;
        for (double num = 2; num < n; num++) {
            boolean isPrime = true;
            for (int i = 2; i <= Math.sqrt(num); i++) {
                if (num % i == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                sum += num;
            }
        }
        return sum;
    }

    public static boolean isPerfectNumber(double num) {
        if (num <= 1) return false;
        int sum = 1;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                sum += i;
                if (i != num / i) sum += num / i;
            }
        }
        return sum == num;
    }

    public static int countCharacterTypes(char input) {
        int uppercaseCount = 0;
        int lowercaseCount = 0;
        int specialCount = 0;

        if (Character.isUpperCase(input)) {
            uppercaseCount++;
        } else if (Character.isLowerCase(input)) {
            lowercaseCount++;
        } else if (!Character.isLetter(input) && !Character.isDigit(input)) {
            specialCount++;
        }

        return uppercaseCount + lowercaseCount + specialCount;
    }


    public static char reverseCase(char ch) {
        if (Character.isUpperCase(ch)) {
            return Character.toLowerCase(ch);
        } else if (Character.isLowerCase(ch)) {
            return Character.toUpperCase(ch);
        }
        return ch;
    }
}
