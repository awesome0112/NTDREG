public class ANumberAfteraDoubleReversal { // added

    public static boolean isSameAfterReversals(int num) {
        if (num <= 9) {
            return true;
        }
        if (num % 10 == 0) {
            return false;
        }
        return true;
    }
}
