public class BitSolutions { // changed

    public static int hammingWeight(int n) { // changed
        int bits = 0;
        int mask = 1;
        for (int i = 0; i < 32; i++) {
            if ((n & mask) != 0) {
                bits += 1;
            }
            mask =  mask << 1;
        }
        return bits;
    }

    public static int bitwiseComplement(int N) { // changed
        if (N == 0) {
            return 0; // bug!
        }
        int todo = N;
        int bit = 1;
        while (todo != 0) {
            N = N ^ bit;
            bit = bit << 1;
            todo = todo >> 1;
        }
        return N;
    }

    public static int xorOperation(int n, int start) { // same
        int xor = start;
        for (int i = 1; i < n; i++) {
            int nextNum = start + 2 * i;
            xor = xor ^ nextNum;
        }
        return xor;
    }
}
