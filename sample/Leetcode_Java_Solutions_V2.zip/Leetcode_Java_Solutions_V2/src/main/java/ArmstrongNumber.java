public class ArmstrongNumber { // changed

    public static boolean isArmstrong(double N) { // same
        double n = getLength(N);
        return getNthPowerSum(N, n) == N;
    }

    public static double getNthPowerSum(double n, double p) { // changed
        double sum = 0.0;
        while (n > 0) {
            double temp = n % 10;
            n = n / 10;
            sum += Math.pow(temp, p);
        }

        return sum;
    }

    public static double getLength(double n) { // same
        double count = 0;
        while (n > 0) {
            n /= 10;
            count++;
        }
        return count;
    }
}
