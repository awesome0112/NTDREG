public class RealLife { // added

    public static int arrangeCoins(int n) {
        long left = 1;
        long right = n;
        while (left <= right) {
            long mid = (left + right) / 2;
            long sum = mid * (mid + 1) / 2;
            if (sum == n) {
                return (int) mid;
            } else if (sum > n) {
                right = mid - 1;
            } else {
                left = mid + 1;
            }
        }
        return (int) right;
    }

    public static int findDelayedArrivalTime(int arrivalTime, int delayedTime) {
        int newTime = arrivalTime + delayedTime;
        if (newTime >= 24) return newTime - 24;
        else return newTime;
    }
}
