public class MathematicsProblems { // changed

    public static boolean isThree(int n) { // same
        int numOfDivisors = 0;
        for (int i = 1; i <= n; i++) {
            if (n % i == 0) {
                numOfDivisors++;
            }
            if (numOfDivisors > 3) {
                return false;
            }
        }
        return numOfDivisors == 3;
    }

    public static boolean isPerfectSquare(int num) { // same
        if (num == 1) {
            return true;
        }
        long start = 2;
        long end = num / 2;
        while (start <= end) {
            long mid = start + (end - start) / 2;
            long currSquare = mid * mid;
            if (currSquare == num) {
                return true;
            }
            if (currSquare > num) {
                end = mid - 1;
            } else {
                start = mid + 1;
            }
        }
        return false;
    }

    public static int countOdds(int low, int high) { // added
        int mid = (high - low) / 2;
        if (low % 2 != 0 || high % 2 != 0) return mid + 1;
        else return mid;
    }
}
