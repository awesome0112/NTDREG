import java.util.stream.IntStream;

public class CountIntegersWithEvenDigitSum { //added

    public static int countEven(int num) {
        return (int) IntStream.range(1, num + 1).boxed().filter(CountIntegersWithEvenDigitSum::isSumOfDigitsEven).count();
    }

    public static boolean isSumOfDigitsEven(int num) {
        int sum = 0;
        while (num > 0) {
            sum += num % 10;
            num /= 10;
        }
        return sum % 2 == 0;
    }
}
