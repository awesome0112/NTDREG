public class ArmstrongNumber {

    public static boolean isArmstrong(double N) {
        double n = getLength(N);
        return getNthPowerSum(N, n) == N;
    }

    public static double getNthPowerSum(double n, double p) {
        double sum = 0.0;
        while (n > 0) {
            double temp = n % 10;
            n /= 10;
            sum += Math.pow(temp, p);
        }

        return sum;
    }

    public static double getLength(double n) {
        double count = 0;
        while (n > 0) {
            n /= 10;
            count++;
        }
        return count;
    }
}
